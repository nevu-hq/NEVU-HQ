# NEVU HQ — Phase 2A

This build adds the first real application shell for:

- Private Holding Home
- Holding Board Room foundation
- Global NEVU HQ
- Holdings Registry
- Personal AI foundation
- Login / Register with Supabase email OTP
- Responsive liquid-glass UI
- Existing `holdings` table lookup by authenticated `user_id`

## Setup

1. Copy `.env.local.example` to `.env.local`.
2. Put your existing Supabase project URL and publishable key in `.env.local`.
3. Run `npm install`.
4. Run `npm run dev`.
5. Open the local address shown by Next.js.

The browser only uses the Supabase publishable key. Provider secrets and OAuth tokens must stay server-side in later phases.

## Important

The four holdings shown in the HQ registry are the agreed NEVU administrator/holding identities. The registry UI is currently the presentation foundation; live cross-holding public data and permission-filtered queries will be wired to the database in the next layer.

The Holding Home queries `public.holdings` using the existing `user_id` column already relied upon by the NEVU security foundation.

Next implementation layer:
- real `nevu_messages` UI and realtime Board Room
- HQ-wide messaging/channel model
- explicit sharing
- presence
- Connected AI accounts
- Connected Apps / agent permissions
- Personal AI private chat + memory
- agent orchestration
- approval workflow and audit events
