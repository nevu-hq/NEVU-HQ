"use client";

import { createClient } from "@/lib/supabase/client";
import { useRouter } from "next/navigation";

export function SignOutButton() {
  const router = useRouter();
  async function signOut() {
    const supabase = createClient();
    await supabase.auth.signOut();
    router.replace("/auth");
  }
  return <button onClick={signOut} className="rounded-xl border border-white/10 px-3 py-2 text-sm text-white/65 hover:bg-white/7 hover:text-white">Sign out</button>;
}
