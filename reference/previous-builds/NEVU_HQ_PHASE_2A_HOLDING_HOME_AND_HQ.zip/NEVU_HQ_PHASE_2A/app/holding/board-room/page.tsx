import Link from "next/link";
import { TopBar } from "@/components/TopBar";

export default function BoardRoomPage() {
  return (
    <main className="min-h-screen">
      <TopBar holdingName="Holding Board Room" />
      <div className="mx-auto max-w-[1200px] px-4 py-7 md:px-7">
        <div className="glass rounded-[2rem] p-6 md:p-8">
          <Link href="/holding" className="text-sm text-white/45 hover:text-white">← Holding Home</Link>
          <h1 className="mt-6 text-3xl font-semibold">Holding Board Room</h1>
          <p className="mt-2 text-sm text-white/45">Private board-room foundation. Messaging, agent participation, new-session capital check, approvals and governance records will plug into this surface.</p>
          <div className="mt-8 grid gap-4 md:grid-cols-3">
            {["Administrator", "Agents", "Governance"].map((x) => <div key={x} className="rounded-2xl border border-white/8 bg-white/[.035] p-5"><div className="font-medium">{x}</div><div className="mt-2 text-sm text-white/40">Foundation ready</div></div>)}
          </div>
        </div>
      </div>
    </main>
  );
}
