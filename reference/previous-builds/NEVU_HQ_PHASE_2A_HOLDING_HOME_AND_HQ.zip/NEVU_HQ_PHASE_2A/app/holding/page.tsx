"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { createClient } from "@/lib/supabase/client";
import { TopBar } from "@/components/TopBar";
import { SignOutButton } from "@/components/SignOutButton";

type Holding = Record<string, unknown>;

export default function HoldingHome() {
  const [email, setEmail] = useState("Administrator");
  const [holding, setHolding] = useState<Holding | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const load = async () => {
      const supabase = createClient();
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        window.location.href = "/auth";
        return;
      }
      setEmail(user.email ?? "Administrator");
      const { data } = await supabase.from("holdings").select("*").eq("user_id", user.id).limit(1).maybeSingle();
      setHolding(data ?? null);
      setLoading(false);
    };
    load();
  }, []);

  const name = String(holding?.holding_name ?? holding?.name ?? "Your Holding");
  const code = String(holding?.nevu_code ?? holding?.code ?? "NEVU");

  return (
    <main className="min-h-screen">
      <TopBar holdingName={name} />
      <div className="mx-auto grid max-w-[1500px] gap-5 px-4 py-7 md:px-7 lg:grid-cols-[250px_1fr]">
        <aside className="glass hidden rounded-3xl p-3 lg:block">
          <div className="px-3 pb-4 pt-2 text-xs uppercase tracking-[.2em] text-white/35">Workspace</div>
          {["Overview", "Board Room", "Portfolio", "Research", "Projects", "Archive"].map((item, i) => (
            <Link key={item} href={item === "Board Room" ? "/holding/board-room" : "#"} className={`mb-1 block rounded-2xl px-3 py-3 text-sm ${i === 0 ? "bg-white/8 text-white" : "text-white/55 hover:bg-white/5 hover:text-white"}`}>
              {item}
            </Link>
          ))}
          <div className="mt-6 border-t border-white/8 pt-4">
            <div className="px-3 text-xs uppercase tracking-[.2em] text-white/35">AI</div>
            <Link href="/personal-ai" className="mt-2 block rounded-2xl px-3 py-3 text-sm text-white/55 hover:bg-white/5 hover:text-white">Personal AI</Link>
          </div>
          <div className="mt-6 px-3"><SignOutButton /></div>
        </aside>

        <section className="space-y-5">
          <div className="glass rounded-[2rem] p-6 md:p-8">
            <div className="flex flex-col justify-between gap-6 md:flex-row md:items-end">
              <div>
                <p className="mb-2 text-xs uppercase tracking-[.25em] text-white/35">Private Holding Workspace</p>
                <h1 className="text-3xl font-semibold tracking-tight md:text-5xl">{loading ? "Loading…" : name}</h1>
                <p className="mt-3 max-w-2xl text-sm leading-6 text-white/55">Welcome back. This is your private NEVU workspace. Holding data, agents, research, projects and Personal AI remain isolated from other holdings unless explicitly shared.</p>
              </div>
              <div className="rounded-2xl border border-white/10 bg-white/5 px-4 py-3 text-left md:text-right">
                <div className="text-xs text-white/35">Administrator</div>
                <div className="mt-1 text-sm">{email}</div>
                <div className="mt-1 text-xs text-white/35">{code}</div>
              </div>
            </div>
          </div>

          <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
            {[
              ["Portfolio", "Capital & performance", "Open workspace"],
              ["Research", "Ideas, evidence & theses", "Open research"],
              ["Projects", "Active investment work", "Open projects"],
              ["Archive", "Decisions & governance", "Open archive"]
            ].map(([title, desc, cta]) => (
              <div key={title} className="glass rounded-3xl p-5">
                <div className="text-lg font-medium">{title}</div>
                <div className="mt-2 text-sm leading-5 text-white/45">{desc}</div>
                <button className="mt-7 text-sm text-white/70 hover:text-white">{cta} →</button>
              </div>
            ))}
          </div>

          <div className="grid gap-5 xl:grid-cols-[1.3fr_.7fr]">
            <div className="glass rounded-3xl p-6">
              <div className="flex items-center justify-between">
                <div><div className="text-lg font-medium">Holding Board Room</div><div className="mt-1 text-sm text-white/40">Private administrator + agents workspace</div></div>
                <Link href="/holding/board-room" className="rounded-xl bg-white px-3 py-2 text-sm font-medium text-black">Open</Link>
              </div>
              <div className="mt-6 rounded-2xl border border-dashed border-white/10 p-5 text-sm text-white/40">Board Room foundation is ready for the WhatsApp-style messaging layer, agents, approvals and session workflow.</div>
            </div>
            <div className="glass rounded-3xl p-6">
              <div className="text-lg font-medium">NEVU AI</div>
              <div className="mt-1 text-sm text-white/40">Tiki + Clog</div>
              <div className="mt-6 flex items-center gap-3 rounded-2xl bg-white/5 p-4">
                <span className="grid h-11 w-11 place-items-center rounded-full bg-white/10 text-xl">✦</span>
                <div><div className="text-sm">Ready</div><div className="text-xs text-white/35">Global HQ companion</div></div>
              </div>
            </div>
          </div>
        </section>
      </div>
    </main>
  );
}
