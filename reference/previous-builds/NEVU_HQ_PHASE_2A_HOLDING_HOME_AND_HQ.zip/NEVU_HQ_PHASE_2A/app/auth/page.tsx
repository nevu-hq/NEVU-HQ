"use client";

import { useState } from "react";
import { createClient } from "@/lib/supabase/client";

export default function AuthPage() {
  const [mode, setMode] = useState<"login"|"register">("login");
  const [email, setEmail] = useState("");
  const [otp, setOtp] = useState("");
  const [step, setStep] = useState<"email"|"otp">("email");
  const [message, setMessage] = useState("");
  const [busy, setBusy] = useState(false);

  async function sendCode() {
    setBusy(true); setMessage("");
    const supabase = createClient();
    const { error } = await supabase.auth.signInWithOtp({
      email: email.trim().toLowerCase(),
      options: { shouldCreateUser: mode === "register" }
    });
    if (error) setMessage(error.message);
    else { setStep("otp"); setMessage("8-digit verification code sent to your email."); }
    setBusy(false);
  }

  async function verify() {
    setBusy(true); setMessage("");
    const supabase = createClient();
    const { error } = await supabase.auth.verifyOtp({
      email: email.trim().toLowerCase(),
      token: otp.trim(),
      type: "email"
    });
    if (error) setMessage(error.message);
    else window.location.href = "/holding";
    setBusy(false);
  }

  return (
    <main className="grid min-h-screen place-items-center px-4 py-10">
      <div className="w-full max-w-md">
        <div className="mb-7 text-center">
          <div className="text-sm font-semibold tracking-[.3em]">NEVU</div>
          <h1 className="mt-3 text-4xl font-semibold">Command center</h1>
          <p className="mt-2 text-sm text-white/45">Private holding access</p>
        </div>
        <div className="glass rounded-[2rem] p-6 md:p-8">
          <div className="mb-6 grid grid-cols-2 rounded-2xl bg-white/5 p-1">
            {(["login","register"] as const).map(m => <button key={m} onClick={() => {setMode(m); setStep("email"); setMessage("");}} className={`rounded-xl py-2.5 text-sm capitalize ${mode===m ? "bg-white text-black" : "text-white/45"}`}>{m}</button>)}
          </div>
          {step === "email" ? (
            <>
              <label className="text-xs text-white/45">Email</label>
              <input value={email} onChange={e=>setEmail(e.target.value)} type="email" placeholder="you@example.com" className="mt-2 w-full rounded-2xl border border-white/10 bg-black/20 px-4 py-3 outline-none placeholder:text-white/20 focus:border-white/25" />
              <button disabled={busy || !email} onClick={sendCode} className="mt-4 w-full rounded-2xl bg-white py-3 text-sm font-medium text-black disabled:opacity-40">{busy ? "Sending…" : "Send verification code"}</button>
            </>
          ) : (
            <>
              <label className="text-xs text-white/45">8-digit verification code</label>
              <input value={otp} onChange={e=>setOtp(e.target.value.replace(/\D/g,"").slice(0,8))} inputMode="numeric" maxLength={8} placeholder="00000000" className="mt-2 w-full rounded-2xl border border-white/10 bg-black/20 px-4 py-4 text-center text-2xl tracking-[.45em] outline-none placeholder:text-white/15 focus:border-white/25" />
              <button disabled={busy || otp.length < 6} onClick={verify} className="mt-4 w-full rounded-2xl bg-white py-3 text-sm font-medium text-black disabled:opacity-40">{busy ? "Verifying…" : "Verify & enter"}</button>
              <button onClick={()=>setStep("email")} className="mt-3 w-full py-2 text-xs text-white/35 hover:text-white">Use a different email</button>
            </>
          )}
          {message && <div className="mt-4 rounded-2xl border border-white/8 bg-white/5 p-3 text-xs leading-5 text-white/55">{message}</div>}
        </div>
      </div>
    </main>
  );
}
