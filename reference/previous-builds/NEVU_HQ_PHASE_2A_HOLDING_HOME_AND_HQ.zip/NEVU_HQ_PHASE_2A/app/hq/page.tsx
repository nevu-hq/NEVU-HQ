"use client";

import Link from "next/link";
import { TopBar } from "@/components/TopBar";
import { SignOutButton } from "@/components/SignOutButton";

const holdings = [
  { name: "Nwachuku Holdings", code: "NEVU-NW", admin: "Nwachuku", status: "Active" },
  { name: "Ezra Holdings", code: "NEVU-EZ", admin: "Ezra", status: "Active" },
  { name: "Victor Holdings", code: "NEVU-VI", admin: "Victor", status: "Active" },
  { name: "Uchechukwu Holdings", code: "NEVU-UC", admin: "Uchechukwu", status: "Active" }
];

export default function HQPage() {
  return (
    <main className="min-h-screen">
      <TopBar holdingName="NEVU HQ" />
      <div className="mx-auto max-w-[1500px] px-4 py-7 md:px-7">
        <div className="glass rounded-[2rem] p-6 md:p-9">
          <div className="flex flex-col justify-between gap-7 md:flex-row md:items-end">
            <div>
              <div className="text-xs uppercase tracking-[.28em] text-white/35">Global Command Center</div>
              <h1 className="mt-2 text-4xl font-semibold tracking-tight md:text-6xl">NEVU HQ</h1>
              <p className="mt-4 max-w-3xl text-sm leading-6 text-white/50">The shared executive layer across NEVU. Administrators can see approved public/high-level holding information here while private holding data stays isolated.</p>
            </div>
            <div className="flex gap-2">
              <Link href="/holding" className="rounded-xl border border-white/10 px-4 py-2.5 text-sm text-white/70 hover:bg-white/7">Return to Holding</Link>
              <SignOutButton />
            </div>
          </div>
        </div>

        <div className="mt-5 grid gap-5 xl:grid-cols-[1fr_340px]">
          <section className="glass rounded-[2rem] p-5 md:p-7">
            <div className="flex items-center justify-between">
              <div><h2 className="text-xl font-medium">Holdings Registry</h2><p className="mt-1 text-sm text-white/40">Shared high-level registry</p></div>
              <span className="rounded-full border border-white/10 bg-white/5 px-3 py-1 text-xs text-white/45">4 holdings</span>
            </div>
            <div className="mt-6 grid gap-3">
              {holdings.map((h) => (
                <div key={h.code} className="rounded-2xl border border-white/8 bg-white/[.035] p-4">
                  <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-center">
                    <div>
                      <div className="font-medium">{h.name}</div>
                      <div className="mt-1 text-xs text-white/35">{h.admin} · {h.code}</div>
                    </div>
                    <div className="flex items-center gap-3">
                      <span className="flex items-center gap-2 text-xs text-white/45"><span className="h-2 w-2 rounded-full bg-emerald-300" />{h.status}</span>
                      <button className="rounded-xl border border-white/10 px-3 py-2 text-xs text-white/55 hover:bg-white/7">View public data</button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </section>

          <aside className="space-y-5">
            <div className="glass rounded-[2rem] p-6">
              <div className="text-xs uppercase tracking-[.2em] text-white/35">NEVU AI</div>
              <div className="mt-3 text-2xl font-semibold">Tiki + Clog</div>
              <p className="mt-2 text-sm leading-6 text-white/45">One global NEVU AI entity. Tiki and Clog are its two companion characters.</p>
              <div className="mt-6 flex items-center gap-3 rounded-2xl bg-white/5 p-4">
                <div className="grid h-12 w-12 place-items-center rounded-full border border-white/10 bg-white/8 text-xl">✦</div>
                <div><div className="text-sm">HQ presence</div><div className="text-xs text-white/35">Available for announcements & events</div></div>
              </div>
            </div>
            <div className="glass rounded-[2rem] p-6">
              <div className="text-xs uppercase tracking-[.2em] text-white/35">Governance</div>
              <div className="mt-3 space-y-3 text-sm text-white/55">
                <div className="rounded-xl bg-white/5 p-3">Explicit sharing only</div>
                <div className="rounded-xl bg-white/5 p-3">Private holding isolation</div>
                <div className="rounded-xl bg-white/5 p-3">Approval phrase enforced server-side</div>
              </div>
            </div>
          </aside>
        </div>
      </div>
    </main>
  );
}
