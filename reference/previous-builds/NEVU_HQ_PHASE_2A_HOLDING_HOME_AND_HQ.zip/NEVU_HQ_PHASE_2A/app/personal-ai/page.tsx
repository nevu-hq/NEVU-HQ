import Link from "next/link";
export default function PersonalAIPage() {
  return (
    <main className="min-h-screen px-4 py-7 md:px-7">
      <div className="mx-auto max-w-[1000px]">
        <Link href="/holding" className="text-sm text-white/45 hover:text-white">← Holding Home</Link>
        <div className="glass mt-5 rounded-[2rem] p-7 md:p-10">
          <div className="text-xs uppercase tracking-[.25em] text-white/35">Private</div>
          <h1 className="mt-2 text-4xl font-semibold">Personal AI</h1>
          <p className="mt-4 max-w-2xl text-sm leading-6 text-white/50">Private Gemini-based Personal AI foundation. Its chat, memory and personality controls will remain visible only to its host administrator.</p>
          <div className="mt-8 grid gap-4 md:grid-cols-2">
            {["Chat & History", "Memory Controls", "Personality", "Connected AI"].map((x) => <div key={x} className="rounded-2xl border border-white/8 bg-white/[.035] p-5"><div className="font-medium">{x}</div><div className="mt-2 text-sm text-white/40">Next build layer</div></div>)}
          </div>
        </div>
      </div>
    </main>
  );
}
