'use client'

import { useMemo, useState } from 'react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import { createClient } from '@/lib/supabase/client'
import AuthShell from '@/components/auth/AuthShell'

// Standard, permissive email check: something@something.tld
const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
function isValidEmail(value: string) {
  return EMAIL_REGEX.test(value)
}

export default function LoginPage() {
  const supabase = useMemo(() => createClient(), [])
  const router = useRouter()

  const [email, setEmail] = useState('')
  const [loading, setLoading] = useState(false)
  const [errorMsg, setErrorMsg] = useState<string | null>(null)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    const trimmed = email.trim().toLowerCase()
    if (!trimmed) return

    if (!isValidEmail(trimmed)) {
      setErrorMsg('Enter a valid email address.')
      return
    }

    setLoading(true)
    setErrorMsg(null)

    const { error } = await supabase.auth.signInWithOtp({
      email: trimmed,
      options: { shouldCreateUser: false },
    })

    if (error) {
      setLoading(false)
      setErrorMsg(
        error.message.toLowerCase().includes('signups not allowed')
          ? 'No account found for this email. Please sign up first.'
          : error.message,
      )
      return
    }

    router.push(`/auth/verify?email=${encodeURIComponent(trimmed)}`)
  }

  return (
    <AuthShell
      title="Sign in to NEVU"
      subtitle="Enter your email and we'll send you an 8-digit verification code to sign in securely."
      footer={
        <span>
          {"Don't have an account? "}
          <Link href="/signup" className="text-blue-400 hover:text-blue-300 transition">
            Create one
          </Link>
        </span>
      }
    >
      <form onSubmit={handleSubmit} noValidate className="flex flex-col gap-4">
        {errorMsg && (
          <div className="bg-red-500/10 border border-red-500/20 rounded-lg px-3 py-2 text-xs text-red-400">
            {errorMsg}
          </div>
        )}

        <div className="flex flex-col gap-1.5">
          <label htmlFor="email" className="text-xs font-medium text-slate-400">
            Email address
          </label>
          <input
            id="email"
            type="email"
            required
            autoComplete="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="you@company.com"
            className="bg-[#0A0D14] border border-slate-700 rounded-lg px-3 py-2.5 text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500/40 transition"
          />
        </div>

        <button
          type="submit"
          disabled={loading || !email.trim()}
          className="w-full px-4 py-2.5 bg-blue-600 hover:bg-blue-500 disabled:opacity-50 disabled:cursor-not-allowed text-white font-medium text-sm rounded-lg transition"
        >
          {loading ? 'Sending code...' : 'Send verification code'}
        </button>
      </form>
    </AuthShell>
  )
}
