'use client'

import { useEffect, useState, useRef, useMemo } from 'react'
import { createClient } from '@/lib/supabase/client'
import TopBar from '@/components/TopBar'
import ShareModal from '@/components/ShareModal'
import Link from 'next/link'

interface HQMessage {
  id: string
  sender_user_id: string
  sender_holding_id: string | null
  sender_legal_name: string | null
  sender_username: string | null
  holding_name: string | null
  nevu_code: string | null
  message: string
  is_explicit_share: boolean
  original_message_id: string | null
  created_at: string
}

export default function HQBoardRoomPage() {
  const supabase = useMemo(() => createClient(), [])

  const [messages, setMessages] = useState<HQMessage[]>([])
  const [newMessage, setNewMessage] = useState('')
  const [loading, setLoading] = useState(true)
  const [errorMsg, setErrorMsg] = useState<string | null>(null)

  const [currentUser, setCurrentUser] = useState<any>(null)
  const [userHolding, setUserHolding] = useState<any>(null)

  const chatBottomRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    let isMounted = true

    async function initHQBoardRoom() {
      try {
        setLoading(true)
        setErrorMsg(null)

        const { data: { user }, error: authError } = await supabase.auth.getUser()
        if (authError || !user) {
          if (isMounted) setErrorMsg('Authentication required.')
          return
        }

        if (isMounted) setCurrentUser(user)

        const { data: holding } = await supabase
          .from('holdings')
          .select('*')
          .eq('user_id', user.id)
          .maybeSingle()

        if (holding && isMounted) {
          setUserHolding(holding)
        }

        const { data: initialMessages, error: fetchError } = await supabase
          .from('nevu_hq_messages')
          .select('*')
          .order('created_at', { ascending: true })

        if (fetchError) {
          if (isMounted) setErrorMsg('Failed to load HQ messages.')
        } else if (initialMessages && isMounted) {
          setMessages(initialMessages)
        }
      } catch (err: any) {
        if (isMounted) setErrorMsg('An unexpected error occurred.')
      } finally {
        if (isMounted) setLoading(false)
      }
    }

    initHQBoardRoom()

    const channel = supabase
      .channel('hq_board_room_realtime')
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'nevu_hq_messages',
        },
        (payload) => {
          const newMsg = payload.new as HQMessage
          setMessages((prev) => {
            if (prev.some((m) => m.id === newMsg.id)) {
              return prev
            }
            return [...prev, newMsg]
          })
        }
      )
      .subscribe()

    return () => {
      isMounted = false
      supabase.removeChannel(channel)
    }
  }, [supabase])

  useEffect(() => {
    chatBottomRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages])

  const handleSendMessage = async () => {
    if (!newMessage.trim() || !currentUser) return

    const textToSend = newMessage.trim()
    setNewMessage('')

    const legalName = userHolding?.legal_name || currentUser.user_metadata?.full_name || 'Administrator'
    const adminUsername = userHolding?.admin_username || currentUser.email?.split('@')[0] || 'admin'
    const holdingName = userHolding?.holding_name || 'HQ Member'
    const nevuCode = userHolding?.nevu_code || 'HQ-000'

    const payload = {
      sender_user_id: currentUser.id,
      sender_holding_id: userHolding?.id || null,
      sender_legal_name: legalName,
      sender_username: adminUsername,
      holding_name: holdingName,
      nevu_code: nevuCode,
      message: textToSend,
      is_explicit_share: false,
    }

    const { error } = await supabase.from('nevu_hq_messages').insert([payload])

    if (error) {
      setErrorMsg('Failed to broadcast message. Please try again.')
    }
  }

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      handleSendMessage()
    }
  }

  return (
    <div className="min-h-screen bg-[#0A0D14] text-slate-100 flex flex-col font-sans">
      <TopBar />

      <main className="flex-1 flex flex-col lg:flex-row overflow-hidden max-w-[1600px] w-full mx-auto p-4 gap-4">
        <aside className="w-full lg:w-64 bg-[#121621] border border-slate-800 rounded-xl p-4 flex flex-col justify-between gap-6 shrink-0">
          <div>
            <h2 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-1">
              NEVU HQ
            </h2>
            <div className="h-0.5 w-8 bg-blue-500 rounded mb-4" />

            <nav className="flex flex-col gap-1 text-sm font-medium">
              <Link
                href="/hq/board-room"
                className="px-3 py-2 rounded-lg bg-blue-600/20 text-blue-400 border border-blue-500/30 flex items-center justify-between"
              >
                <span>HQ Board Room</span>
                <span className="w-2 h-2 rounded-full bg-blue-400 animate-pulse" />
              </Link>
              <Link
                href="/hq"
                className="px-3 py-2 rounded-lg text-slate-400 hover:bg-slate-800/60 hover:text-slate-200 transition"
              >
                Holdings Registry
              </Link>
              <div className="px-3 py-2 rounded-lg text-slate-600 cursor-not-allowed">
                Shared Content
              </div>
              <div className="px-3 py-2 rounded-lg text-slate-600 cursor-not-allowed">
                Events
              </div>
              <div className="px-3 py-2 rounded-lg text-slate-600 cursor-not-allowed">
                Announcements
              </div>
            </nav>
          </div>

          <div className="pt-4 border-t border-slate-800/80">
            <Link
              href="/holding"
              className="text-xs text-slate-400 hover:text-slate-200 flex items-center gap-1 transition"
            >
              ← Return to Private Holding
            </Link>
          </div>
        </aside>

        <section className="flex-1 bg-[#121621] border border-slate-800 rounded-xl flex flex-col overflow-hidden min-h-[500px]">
          <div className="px-6 py-4 border-b border-slate-800 flex justify-between items-center bg-[#161B26]">
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-lg font-bold text-slate-100">NEVU HQ Board Room</h1>
                <span className="text-[10px] uppercase tracking-wider px-2 py-0.5 rounded bg-amber-500/10 text-amber-400 border border-amber-500/20">
                  Global / Shared
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                Central communication layer across all authorized holdings
              </p>
            </div>

            <div className="flex items-center gap-2 text-xs text-slate-400">
              <span className="w-2 h-2 rounded-full bg-emerald-500" />
              <span className="hidden sm:inline">Realtime Connected</span>
            </div>
          </div>

          {errorMsg && (
            <div className="bg-red-500/10 border-b border-red-500/20 px-6 py-2 text-xs text-red-400 flex justify-between items-center">
              <span>{errorMsg}</span>
              <button
                onClick={() => setErrorMsg(null)}
                className="text-red-400 hover:text-red-200 font-bold ml-4"
              >
                ✕
              </button>
            </div>
          )}

          <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4">
            {loading ? (
              <div className="flex h-full items-center justify-center text-xs text-slate-500">
                Loading HQ Board Room timeline...
              </div>
            ) : messages.length === 0 ? (
              <div className="flex flex-col h-full items-center justify-center text-center p-6 text-slate-500">
                <p className="text-sm font-medium text-slate-400">No HQ messages yet</p>
                <p className="text-xs mt-1 max-w-sm">
                  Messages posted here or explicitly shared from private board rooms will appear in this global stream.
                </p>
              </div>
            ) : (
              messages.map((msg) => {
                const isSelf = msg.sender_user_id === currentUser?.id
                return (
                  <div
                    key={msg.id}
                    className={`flex flex-col ${isSelf ? 'items-end' : 'items-start'}`}
                  >
                    <div className="flex items-center gap-2 mb-1 px-1 flex-wrap">
                      <span className="text-xs font-semibold text-slate-300">
                        {msg.sender_legal_name || 'Administrator'}
                      </span>
                      <span className="text-[11px] text-blue-400 font-mono">
                        ({msg.holding_name || 'HQ Member'})
                      </span>
                      {msg.is_explicit_share && (
                        <span className="text-[9px] uppercase px-1.5 py-0.2 rounded bg-purple-500/20 text-purple-300 border border-purple-500/30">
                          Shared Resource
                        </span>
                      )}
                      <span className="text-[10px] text-slate-500">
                        {new Date(msg.created_at).toLocaleTimeString([], {
                          hour: '2-digit',
                          minute: '2-digit',
                        })}
                      </span>
                    </div>

                    <div
                      className={`max-w-xl rounded-xl px-4 py-2.5 text-sm whitespace-pre-wrap ${
                        isSelf
                          ? 'bg-blue-600 text-white rounded-tr-none'
                          : 'bg-slate-800/90 text-slate-100 rounded-tl-none border border-slate-700/50'
                      }`}
                    >
                      {msg.message}
                    </div>
                  </div>
                )
              })
            )}
            <div ref={chatBottomRef} />
          </div>

          <div className="p-4 border-t border-slate-800 bg-[#161B26]">
            <div className="flex gap-2">
              <textarea
                value={newMessage}
                onChange={(e) => setNewMessage(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder="Broadcast a message to NEVU HQ... (Enter to send, Shift+Enter for new line)"
                className="flex-1 bg-[#0A0D14] border border-slate-700 rounded-lg p-3 text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:border-blue-500 resize-none h-14"
              />
              <button
                onClick={handleSendMessage}
                disabled={!newMessage.trim()}
                className="px-5 bg-blue-600 hover:bg-blue-500 disabled:opacity-50 disabled:cursor-not-allowed text-white font-medium text-sm rounded-lg transition flex items-center justify-center shrink-0"
              >
                Send
              </button>
            </div>
          </div>
        </section>

        <aside className="w-full lg:w-80 bg-[#121621] border border-slate-800 rounded-xl p-4 flex flex-col gap-4 shrink-0">
          <div>
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-1">
              Shared Content
            </h3>
            <div className="h-0.5 w-8 bg-purple-500 rounded mb-4" />
          </div>

          <div className="space-y-3 text-xs text-slate-400 flex-1 overflow-y-auto">
            <div className="p-3 bg-[#161B26] rounded-lg border border-slate-800">
              <div className="font-semibold text-slate-300 mb-1">Research Reports</div>
              <p className="text-[11px] text-slate-500">No explicitly shared research yet.</p>
            </div>

            <div className="p-3 bg-[#161B26] rounded-lg border border-slate-800">
              <div className="font-semibold text-slate-300 mb-1">Decisions & Minutes</div>
              <p className="text-[11px] text-slate-500">No governance records shared to HQ.</p>
            </div>

            <div className="p-3 bg-[#161B26] rounded-lg border border-slate-800">
              <div className="font-semibold text-slate-300 mb-1">Portfolio Snapshots</div>
              <p className="text-[11px] text-slate-500">No public portfolio summaries shared.</p>
            </div>

            <div className="p-3 bg-[#161B26] rounded-lg border border-slate-800">
              <div className="font-semibold text-slate-300 mb-1">Agent Outputs</div>
              <p className="text-[11px] text-slate-500">No shared agent execution results.</p>
            </div>
          </div>

          <div className="p-3 rounded-lg bg-slate-900/50 border border-slate-800/80 text-[11px] text-slate-500">
            🔒 Explicit Sharing Foundation: Items will be populated here when administrators use Phase 8 sharing features.
          </div>
        </aside>
      </main>
    </div>
  )
}
