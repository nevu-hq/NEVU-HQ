<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>NEVU HQ — Holding</title>
  <script src="https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2"></script>
  <script src="https://cdn.tailwindcss.com"></script>
  <style>
    html, body { background: #05070d; }
    body { font-family: Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif; }
    .glass {
      background: rgba(15, 23, 42, 0.62);
      border: 1px solid rgba(148, 163, 184, 0.16);
      backdrop-filter: blur(24px);
      -webkit-backdrop-filter: blur(24px);
      box-shadow: 0 24px 80px rgba(0, 0, 0, 0.35);
    }
    .ambient {
      position: fixed;
      pointer-events: none;
      border-radius: 999px;
      filter: blur(90px);
      opacity: 0.18;
    }
    .ambient.a { width: 380px; height: 380px; top: -140px; left: -120px; background: #6366f1; }
    .ambient.b { width: 320px; height: 320px; right: -100px; bottom: -100px; background: #06b6d4; }
  </style>
</head>
<body class="min-h-screen text-white overflow-x-hidden">
  <div class="ambient a"></div>
  <div class="ambient b"></div>

  <!-- Top Bar -->
  <header class="relative z-10 border-b border-white/5">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between">
      <div class="flex items-center gap-3">
        <div class="h-8 w-8 rounded-lg bg-white/10 flex items-center justify-center text-sm font-bold">N</div>
        <div>
          <div class="text-sm font-semibold tracking-wide">NEVU HQ</div>
          <div class="text-[11px] text-slate-400" id="holdingNameLabel">Loading holding...</div>
        </div>
      </div>

      <div class="flex items-center gap-3">
        <div class="hidden sm:block text-right">
          <div class="text-xs text-slate-400">Administrator</div>
          <div class="text-sm" id="adminEmail">—</div>
        </div>
        <button onclick="signOut()" class="text-xs px-3 py-2 rounded-lg border border-white/10 hover:bg-white/5 transition">
          Sign out
        </button>
      </div>
    </div>
  </header>

  <main class="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 py-8">
    <!-- Welcome Section -->
    <div class="mb-8">
      <h1 class="text-3xl sm:text-4xl font-bold tracking-tight">Holding Home</h1>
      <p class="text-slate-400 mt-2">Your private workspace inside NEVU HQ</p>
    </div>

    <!-- Status Cards -->
    <div class="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
      <div class="glass rounded-2xl p-5">
        <div class="text-xs uppercase tracking-wider text-slate-400 mb-2">Holding</div>
        <div class="text-xl font-semibold" id="cardHoldingName">—</div>
        <div class="text-sm text-slate-400 mt-1" id="cardNevoCode">Code: —</div>
      </div>

      <div class="glass rounded-2xl p-5">
        <div class="text-xs uppercase tracking-wider text-slate-400 mb-2">Status</div>
        <div class="flex items-center gap-2">
          <span class="h-2.5 w-2.5 rounded-full bg-emerald-400"></span>
          <span class="text-xl font-semibold">Active</span>
        </div>
        <div class="text-sm text-slate-400 mt-1">Ready for operations</div>
      </div>

      <div class="glass rounded-2xl p-5">
        <div class="text-xs uppercase tracking-wider text-slate-400 mb-2">Administrator</div>
        <div class="text-xl font-semibold" id="cardAdminName">—</div>
        <div class="text-sm text-slate-400 mt-1" id="cardAdminEmail">—</div>
      </div>
    </div>

    <!-- Main Actions -->
    <div class="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-5">
      <!-- Board Room -->
      <a href="/holding/board-room" class="glass rounded-2xl p-6 hover:border-indigo-400/40 transition group">
        <div class="flex items-center justify-between mb-4">
          <span class="text-xs font-semibold uppercase tracking-wider text-indigo-300">Core</span>
          <span class="h-2 w-2 rounded-full bg-indigo-400 group-hover:scale-125 transition"></span>
        </div>
        <h3 class="text-xl font-semibold mb-2">Board Room</h3>
        <p class="text-sm text-slate-400 leading-relaxed">
          Enter the private decision room with agents, approvals, minutes and archive.
        </p>
        <div class="mt-6 text-sm text-indigo-300 group-hover:text-indigo-200">Open Board Room →</div>
      </a>

      <!-- Portfolio -->
      <div class="glass rounded-2xl p-6">
        <div class="flex items-center justify-between mb-4">
          <span class="text-xs font-semibold uppercase tracking-wider text-slate-400">Workspace</span>
        </div>
        <h3 class="text-xl font-semibold mb-2">Portfolio</h3>
        <p class="text-sm text-slate-400 leading-relaxed">
          Capital allocation, positions, performance and portfolio architecture.
        </p>
        <div class="mt-6 text-sm text-slate-500">Coming next</div>
      </div>

      <!-- Archive -->
      <div class="glass rounded-2xl p-6">
        <div class="flex items-center justify-between mb-4">
          <span class="text-xs font-semibold uppercase tracking-wider text-slate-400">Records</span>
        </div>
        <h3 class="text-xl font-semibold mb-2">Archive</h3>
        <p class="text-sm text-slate-400 leading-relaxed">
          Official decisions, approved sessions, and historical records.
        </p>
        <div class="mt-6 text-sm text-slate-500">Coming next</div>
      </div>

      <!-- Personal AI -->
      <div class="glass rounded-2xl p-6">
        <div class="flex items-center justify-between mb-4">
          <span class="text-xs font-semibold uppercase tracking-wider text-cyan-300">AI</span>
        </div>
        <h3 class="text-xl font-semibold mb-2">Personal AI</h3>
        <p class="text-sm text-slate-400 leading-relaxed">
          Your private advisor agent connected only to you.
        </p>
        <div class="mt-6 text-sm text-slate-500">Coming next</div>
      </div>

      <!-- Research -->
      <div class="glass rounded-2xl p-6">
        <div class="flex items-center justify-between mb-4">
          <span class="text-xs font-semibold uppercase tracking-wider text-slate-400">Intelligence</span>
        </div>
        <h3 class="text-xl font-semibold mb-2">Research</h3>
        <p class="text-sm text-slate-400 leading-relaxed">
          Market context, company analysis and structured research notes.
        </p>
        <div class="mt-6 text-sm text-slate-500">Coming next</div>
      </div>

      <!-- Settings -->
      <div class="glass rounded-2xl p-6">
        <div class="flex items-center justify-between mb-4">
          <span class="text-xs font-semibold uppercase tracking-wider text-slate-400">System</span>
        </div>
        <h3 class="text-xl font-semibold mb-2">Holding Settings</h3>
        <p class="text-sm text-slate-400 leading-relaxed">
          Administrator controls, connected AI accounts and security.
        </p>
        <div class="mt-6 text-sm text-slate-500">Coming next</div>
      </div>
    </div>
  </main>

  <script>
    // ====================== CONFIG ======================
    const SUPABASE_URL = "YOUR_SUPABASE_URL_HERE";
    const SUPABASE_ANON_KEY = "YOUR_SUPABASE_ANON_KEY_HERE";
    // ====================================================

    const supabaseClient = supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

    async function loadHolding() {
      try {
        const { data: { user }, error: userError } = await supabaseClient.auth.getUser();

        if (userError || !user) {
          window.location.href = "/"; // back to auth page
          return;
        }

        // Set email
        document.getElementById("adminEmail").textContent = user.email || "—";
        document.getElementById("cardAdminEmail").textContent = user.email || "—";

        // Try to load holding information
        const { data: holding, error } = await supabaseClient
          .from("holdings")
          .select("*")
          .eq("user_id", user.id)
          .limit(1)
          .maybeSingle();

        if (holding) {
          const name = holding.holding_name || holding.name || "Your Holding";
          const code = holding.nevu_code || holding.code || "—";
          const adminName = holding.admin_username || holding.legal_name || "Administrator";

          document.getElementById("holdingNameLabel").textContent = name;
          document.getElementById("cardHoldingName").textContent = name;
          document.getElementById("cardNevoCode").textContent = `Code: ${code}`;
          document.getElementById("cardAdminName").textContent = adminName;
        } else {
          document.getElementById("holdingNameLabel").textContent = "Holding";
          document.getElementById("cardHoldingName").textContent = "No holding found";
        }
      } catch (err) {
        console.error(err);
        document.getElementById("holdingNameLabel").textContent = "Error loading holding";
      }
    }

    async function signOut() {
      await supabaseClient.auth.signOut();
      window.location.href = "/";
    }

    // Load data when page opens
    loadHolding();
  </script>
</body>
</html>