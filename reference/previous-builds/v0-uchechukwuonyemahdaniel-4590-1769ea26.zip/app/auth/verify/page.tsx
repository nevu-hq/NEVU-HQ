'use client'

import { Suspense, useEffect, useMemo, useState } from 'react'
import { useRouter, useSearchParams } from 'next/navigation'
import Link from 'next/link'
import { createClient } from '@/lib/supabase/client'
import AuthShell from '@/components/auth/AuthShell'
import OtpInput from '@/components/auth/OtpInput'

const OTP_LENGTH = 8
const RESEND_SECONDS = 45

function VerifyContent() {
  const supabase = useMemo(() => createClient(), [])
  const router = useRouter()
  const searchParams = useSearchParams()

  const email = (searchParams.get('email') || '').toLowerCase()
  const isSignup = searchParams.get('mode') === 'signup'

  const [code, setCode] = useState('')
  const [verifying, setVerifying] = useState(false)
  const [errorMsg, setErrorMsg] = useState<string | null>(null)
  const [resendIn, setResendIn] = useState(RESEND_SECONDS)
  const [resendMsg, setResendMsg] = useState<string | null>(null)

  useEffect(() => {
    if (resendIn <= 0) return
    const timer = setInterval(() => setResendIn((s) => s - 1), 1000)
    return () => clearInterval(timer)
  }, [resendIn])

  const verify = async (token: string) => {
    if (token.length !== OTP_LENGTH || !email) return

    setVerifying(true)
    setErrorMsg(null)

    const { error } = await supabase.auth.verifyOtp({
      email,
      token,
      type: 'email',
    })

    if (error) {
      setVerifying(false)
      setCode('')
      setErrorMsg('Invalid or expired code. Please try again.')
      return
    }

    // Session is now active and persisted in cookies.
    router.push('/holding')
  }

  const handleResend = async () => {
    if (resendIn > 0 || !email) return
    setResendMsg(null)
    setErrorMsg(null)

    const { error } = await supabase.auth.signInWithOtp({
      email,
      options: { shouldCreateUser: isSignup },
    })

    if (error) {
      setErrorMsg(error.message)
      return
    }

    setResendMsg('A new code has been sent to your email.')
    setResendIn(RESEND_SECONDS)
  }

  if (!email) {
    return (
      <AuthShell
        title="Verification link invalid"
        subtitle="We couldn't determine which email to verify. Please start again."
      >
        <Link
          href="/login"
          className="block w-full text-center px-4 py-2.5 bg-blue-600 hover:bg-blue-500 text-white font-medium text-sm rounded-lg transition"
        >
          Back to sign in
        </Link>
      </AuthShell>
    )
  }

  return (
    <AuthShell
      title="Enter verification code"
      subtitle={`We sent an 8-digit code to ${email}. Enter it below to continue.`}
      footer={
        <Link href="/login" className="text-blue-400 hover:text-blue-300 transition">
          Use a different email
        </Link>
      }
    >
      <div className="flex flex-col gap-5">
        {errorMsg && (
          <div className="bg-red-500/10 border border-red-500/20 rounded-lg px-3 py-2 text-xs text-red-400">
            {errorMsg}
          </div>
        )}
        {resendMsg && (
          <div className="bg-emerald-500/10 border border-emerald-500/20 rounded-lg px-3 py-2 text-xs text-emerald-400">
            {resendMsg}
          </div>
        )}

        <OtpInput
          length={OTP_LENGTH}
          value={code}
          onChange={setCode}
          onComplete={verify}
          disabled={verifying}
        />

        <button
          type="button"
          onClick={() => verify(code)}
          disabled={verifying || code.length !== OTP_LENGTH}
          className="w-full px-4 py-2.5 bg-blue-600 hover:bg-blue-500 disabled:opacity-50 disabled:cursor-not-allowed text-white font-medium text-sm rounded-lg transition"
        >
          {verifying ? 'Verifying...' : 'Verify and continue'}
        </button>

        <div className="text-center text-xs text-slate-500">
          {resendIn > 0 ? (
            <span>Resend code in {resendIn}s</span>
          ) : (
            <button
              type="button"
              onClick={handleResend}
              className="text-blue-400 hover:text-blue-300 transition"
            >
              Resend code
            </button>
          )}
        </div>
      </div>
    </AuthShell>
  )
}

export default function VerifyPage() {
  return (
    <Suspense
      fallback={
        <div className="min-h-screen bg-[#0A0D14] flex items-center justify-center text-xs text-slate-500">
          Loading...
        </div>
      }
    >
      <VerifyContent />
    </Suspense>
  )
}
