'use client'

import Link from 'next/link'
import type { ReactNode } from 'react'

interface AuthShellProps {
  title: string
  subtitle: string
  children: ReactNode
  footer?: ReactNode
}

export default function AuthShell({
  title,
  subtitle,
  children,
  footer,
}: AuthShellProps) {
  return (
    <div className="min-h-screen bg-[#0A0D14] text-slate-100 flex flex-col font-sans">
      <header className="w-full border-b border-slate-800">
        <div className="max-w-[1600px] mx-auto px-4 h-14 flex items-center">
          <Link href="/" className="flex items-center gap-2">
            <span className="w-6 h-6 rounded bg-blue-600 flex items-center justify-center text-xs font-bold text-white">
              N
            </span>
            <span className="text-sm font-semibold tracking-wide text-slate-100">
              NEVU
            </span>
          </Link>
        </div>
      </header>

      <main className="flex-1 flex items-center justify-center p-4">
        <div className="w-full max-w-md">
          <div className="bg-[#121621] border border-slate-800 rounded-xl p-6 sm:p-8">
            <div className="mb-6">
              <h1 className="text-xl font-bold text-slate-100 text-balance">
                {title}
              </h1>
              <div className="h-0.5 w-8 bg-blue-500 rounded mt-2 mb-3" />
              <p className="text-sm text-slate-400 leading-relaxed text-pretty">
                {subtitle}
              </p>
            </div>

            {children}
          </div>

          {footer && (
            <div className="mt-4 text-center text-xs text-slate-500">
              {footer}
            </div>
          )}
        </div>
      </main>
    </div>
  )
}
