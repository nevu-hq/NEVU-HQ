'use client'

import Link from 'next/link'

export default function TopBar() {
  return (
    <header className="w-full border-b border-slate-800 bg-[#0A0D14]">
      <div className="max-w-[1600px] mx-auto px-4 h-14 flex items-center justify-between">
        <Link href="/" className="flex items-center gap-2">
          <span className="w-6 h-6 rounded bg-blue-600 flex items-center justify-center text-xs font-bold text-white">
            N
          </span>
          <span className="text-sm font-semibold tracking-wide text-slate-100">
            NEVU
          </span>
        </Link>

        <nav className="flex items-center gap-4 text-xs font-medium text-slate-400">
          <Link href="/hq" className="hover:text-slate-200 transition">
            HQ
          </Link>
          <Link href="/holding" className="hover:text-slate-200 transition">
            Holding
          </Link>
        </nav>
      </div>
    </header>
  )
}
