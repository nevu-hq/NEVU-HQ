'use client'

import { useEffect, useMemo, useState } from 'react'
import { createClient } from '@/lib/supabase/client'

type ResourceType =
  | 'holding_summary'
  | 'investment_analysis'
  | 'message_thread'

const RESOURCE_OPTIONS: { value: ResourceType; label: string; hint: string }[] = [
  {
    value: 'holding_summary',
    label: 'Holding Summary',
    hint: 'High-level overview of your holding.',
  },
  {
    value: 'investment_analysis',
    label: 'Investment Analysis',
    hint: 'Research and analysis records.',
  },
  {
    value: 'message_thread',
    label: 'Message Thread',
    hint: 'A board room conversation.',
  },
]

interface ShareModalProps {
  open: boolean
  onClose: () => void
  senderHoldingId: string | null
  senderUserId: string | null
  senderHoldingName?: string | null
  onShared?: () => void
}

export default function ShareModal({
  open,
  onClose,
  senderHoldingId,
  senderUserId,
  senderHoldingName,
  onShared,
}: ShareModalProps) {
  const supabase = useMemo(() => createClient(), [])

  const [recipientCode, setRecipientCode] = useState('')
  const [resourceType, setResourceType] = useState<ResourceType>('holding_summary')
  const [message, setMessage] = useState('')

  const [submitting, setSubmitting] = useState(false)
  const [errorMsg, setErrorMsg] = useState<string | null>(null)
  const [successMsg, setSuccessMsg] = useState<string | null>(null)

  // Reset transient state whenever the modal is opened.
  useEffect(() => {
    if (open) {
      setErrorMsg(null)
      setSuccessMsg(null)
    }
  }, [open])

  // Close on Escape.
  useEffect(() => {
    if (!open) return
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose()
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [open, onClose])

  if (!open) return null

  const resetForm = () => {
    setRecipientCode('')
    setResourceType('holding_summary')
    setMessage('')
  }

  const handleCodeChange = (value: string) => {
    // Keep digits only, max 6 characters.
    const digits = value.replace(/\D/g, '').slice(0, 6)
    setRecipientCode(digits)
  }

  const handleShare = async () => {
    setErrorMsg(null)
    setSuccessMsg(null)

    const code = recipientCode.trim()

    if (code.length !== 6) {
      setErrorMsg('Enter a valid 6-digit NEVU Code.')
      return
    }

    if (!senderHoldingId || !senderUserId) {
      setErrorMsg('Your holding could not be identified. Please try again later.')
      return
    }

    setSubmitting(true)

    try {
      // 1. Resolve the recipient holding from its 6-digit NEVU code.
      const { data: codeRow, error: lookupError } = await supabase
        .from('nevu_holding_codes')
        .select('holding_id, nevu_code')
        .eq('nevu_code', code)
        .maybeSingle()

      if (lookupError) {
        setErrorMsg('Failed to look up that NEVU Code. Please try again.')
        setSubmitting(false)
        return
      }

      if (!codeRow || !codeRow.holding_id) {
        setErrorMsg('No holding found for that NEVU Code.')
        setSubmitting(false)
        return
      }

      if (codeRow.holding_id === senderHoldingId) {
        setErrorMsg('You cannot share a resource with your own holding.')
        setSubmitting(false)
        return
      }

      // 2. Insert the share record.
      const payload = {
        sender_holding_id: senderHoldingId,
        sender_user_id: senderUserId,
        recipient_holding_id: codeRow.holding_id,
        resource_type: resourceType,
        message: message.trim() || null,
      }

      const { error: insertError } = await supabase
        .from('nevu_shares')
        .insert([payload])

      if (insertError) {
        setErrorMsg('Failed to share the resource. Please try again.')
        setSubmitting(false)
        return
      }

      const label =
        RESOURCE_OPTIONS.find((r) => r.value === resourceType)?.label ??
        'Resource'
      setSuccessMsg(`${label} shared with holding ${code}.`)
      resetForm()
      onShared?.()
    } catch {
      setErrorMsg('An unexpected error occurred while sharing.')
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="share-modal-title"
    >
      {/* Backdrop */}
      <button
        type="button"
        aria-label="Close share dialog"
        onClick={onClose}
        className="absolute inset-0 bg-black/70 backdrop-blur-sm"
      />

      {/* Panel */}
      <div className="relative w-full max-w-md bg-[#121621] border border-slate-800 rounded-xl shadow-2xl overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-800 bg-[#161B26] flex items-start justify-between gap-4">
          <div>
            <h2
              id="share-modal-title"
              className="text-base font-bold text-slate-100"
            >
              Share a Resource
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              {senderHoldingName
                ? `Sharing from ${senderHoldingName}`
                : 'Send a resource to another holding'}
            </p>
          </div>
          <button
            onClick={onClose}
            className="text-slate-500 hover:text-slate-200 font-bold text-sm leading-none mt-1"
            aria-label="Close"
          >
            ✕
          </button>
        </div>

        <div className="p-6 flex flex-col gap-5">
          {errorMsg && (
            <div className="bg-red-500/10 border border-red-500/20 rounded-lg px-3 py-2 text-xs text-red-400">
              {errorMsg}
            </div>
          )}
          {successMsg && (
            <div className="bg-emerald-500/10 border border-emerald-500/20 rounded-lg px-3 py-2 text-xs text-emerald-400">
              {successMsg}
            </div>
          )}

          {/* Recipient NEVU Code */}
          <div className="flex flex-col gap-1.5">
            <label
              htmlFor="recipient-code"
              className="text-xs font-semibold uppercase tracking-wider text-slate-400"
            >
              Recipient NEVU Code
            </label>
            <input
              id="recipient-code"
              inputMode="numeric"
              autoComplete="off"
              value={recipientCode}
              onChange={(e) => handleCodeChange(e.target.value)}
              placeholder="6-digit code"
              className="bg-[#0A0D14] border border-slate-700 rounded-lg px-3 py-2.5 text-sm text-slate-100 placeholder-slate-500 tracking-[0.3em] font-mono focus:outline-none focus:border-blue-500"
            />
            <span className="text-[11px] text-slate-500">
              The unique 6-digit code of the destination holding.
            </span>
          </div>

          {/* Resource type */}
          <div className="flex flex-col gap-1.5">
            <label
              htmlFor="resource-type"
              className="text-xs font-semibold uppercase tracking-wider text-slate-400"
            >
              Resource Type
            </label>
            <select
              id="resource-type"
              value={resourceType}
              onChange={(e) => setResourceType(e.target.value as ResourceType)}
              className="bg-[#0A0D14] border border-slate-700 rounded-lg px-3 py-2.5 text-sm text-slate-100 focus:outline-none focus:border-blue-500"
            >
              {RESOURCE_OPTIONS.map((opt) => (
                <option key={opt.value} value={opt.value}>
                  {opt.label}
                </option>
              ))}
            </select>
            <span className="text-[11px] text-slate-500">
              {RESOURCE_OPTIONS.find((r) => r.value === resourceType)?.hint}
            </span>
          </div>

          {/* Optional message */}
          <div className="flex flex-col gap-1.5">
            <label
              htmlFor="share-message"
              className="text-xs font-semibold uppercase tracking-wider text-slate-400"
            >
              Message <span className="text-slate-600 normal-case">(optional)</span>
            </label>
            <textarea
              id="share-message"
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Add a note for the recipient..."
              className="bg-[#0A0D14] border border-slate-700 rounded-lg px-3 py-2.5 text-sm text-slate-100 placeholder-slate-500 resize-none h-20 focus:outline-none focus:border-blue-500"
            />
          </div>
        </div>

        <div className="px-6 py-4 border-t border-slate-800 bg-[#161B26] flex justify-end gap-2">
          <button
            onClick={onClose}
            className="text-xs text-slate-400 hover:text-slate-200 border border-slate-800 hover:border-slate-700 rounded-lg px-4 py-2 transition"
          >
            Cancel
          </button>
          <button
            onClick={handleShare}
            disabled={submitting || recipientCode.length !== 6}
            className="px-5 py-2 bg-blue-600 hover:bg-blue-500 disabled:opacity-50 disabled:cursor-not-allowed text-white font-medium text-sm rounded-lg transition"
          >
            {submitting ? 'Sharing...' : 'Share'}
          </button>
        </div>
      </div>
    </div>
  )
}
