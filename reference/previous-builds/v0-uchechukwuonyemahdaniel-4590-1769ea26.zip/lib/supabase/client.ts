import { createBrowserClient } from '@supabase/ssr'

function normalizeSupabaseUrl(value: string | undefined): string {
  if (!value) return ''
  const trimmed = value.trim()
  // Already a full URL
  if (/^https?:\/\//i.test(trimmed)) return trimmed
  // Bare project ref (e.g. "ecmqsosxaqmbqehmczxu") -> full URL
  return `https://${trimmed}.supabase.co`
}

export function createClient() {
  return createBrowserClient(
    normalizeSupabaseUrl(process.env.NEXT_PUBLIC_SUPABASE_URL),
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
  )
}
