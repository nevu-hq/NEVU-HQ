# NEVU HQ Foundation v2

This is the first application-layer upgrade from the supplied working OTP registration page.

Included:
- Registration / Login toggle
- Registration uses Supabase OTP with shouldCreateUser=true
- Login uses Supabase OTP with shouldCreateUser=false
- Existing activate_nevu_holding RPC retained
- 8-digit OTP UI retained
- Responsive liquid-glass foundation
- No AI provider keys embedded in the browser

Next build stage:
1. Private holding workspace
2. NEVU HQ / Board Room
3. Database/RLS expansion
4. Secure connected AI account authorization
5. Agents and Personal AI
