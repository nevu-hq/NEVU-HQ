"use client";

import { FormEvent, KeyboardEvent, useEffect, useMemo, useRef, useState } from "react";
import Link from "next/link";
import { createClient } from "@/lib/supabase/client";
import { TopBar } from "@/components/TopBar";

type Message = {
  id: string;
  holding_id: string;
  sender_legal_name: string;
  sender_username: string;
  holding_name: string;
  nevu_code: string;
  message: string;
  created_at: string;
};

function formatTime(value: string) {
  return new Intl.DateTimeFormat(undefined, { hour: "2-digit", minute: "2-digit" }).format(new Date(value));
}

function formatDay(value: string) {
  return new Intl.DateTimeFormat(undefined, { weekday: "short", month: "short", day: "numeric" }).format(new Date(value));
}

export default function HoldingBoardRoom() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [text, setText] = useState("");
  const [holding, setHolding] = useState<{ id: string; name: string; code: string } | null>(null);
  const [user, setUser] = useState<{ id: string; email?: string } | null>(null);
  const [loading, setLoading] = useState(true);
  const [sending, setSending] = useState(false);
  const [error, setError] = useState("");
  const [connected, setConnected] = useState(false);
  const bottomRef = useRef<HTMLDivElement | null>(null);

  const supabase = useMemo(() => createClient(), []);

  useEffect(() => {
    let mounted = true;

    async function load() {
      setLoading(true);
      setError("");

      const { data: { user: currentUser } } = await supabase.auth.getUser();
      if (!currentUser) {
        window.location.href = "/auth";
        return;
      }
      if (!mounted) return;
      setUser({ id: currentUser.id, email: currentUser.email });

      const { data: h, error: holdingError } = await supabase
        .from("holdings")
        .select("*")
        .eq("user_id", currentUser.id)
        .limit(1)
        .maybeSingle();

      if (holdingError || !h) {
        setError(holdingError?.message ?? "No holding is connected to this account.");
        setLoading(false);
        return;
      }

      const holdingId = String(h.id);
      const holdingName = String(h.holding_name ?? h.name ?? "Your Holding");
      const code = String(h.nevu_code ?? h.code ?? "NEVU");
      setHolding({ id: holdingId, name: holdingName, code });

      const { data: rows, error: messageError } = await supabase
        .from("nevu_messages")
        .select("id,holding_id,sender_legal_name,sender_username,holding_name,nevu_code,message,created_at")
        .eq("holding_id", holdingId)
        .order("created_at", { ascending: true })
        .limit(500);

      if (messageError) setError(messageError.message);
      else setMessages((rows ?? []) as Message[]);
      setLoading(false);

      const channel = supabase
        .channel(`nevu-holding-board-room-${holdingId}`)
        .on("postgres_changes", { event: "INSERT", schema: "public", table: "nevu_messages", filter: `holding_id=eq.${holdingId}` },
          (payload) => {
            const next = payload.new as Message;
            setMessages(prev => prev.some(m => m.id === next.id) ? prev : [...prev, next]);
          })
        .subscribe(status => {
          setConnected(status === "SUBSCRIBED");
        });

      return () => {
        mounted = false;
        supabase.removeChannel(channel);
      };
    }

    load();
    return () => { mounted = false; };
  }, [supabase]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages.length]);

  async function sendMessage(e?: FormEvent) {
    e?.preventDefault();
    const value = text.trim();
    if (!value || !holding || !user || sending) return;

    setSending(true);
    setError("");

    const { data: row, error: insertError } = await supabase
      .from("nevu_messages")
      .insert({
        holding_id: holding.id,
        sender_legal_name: holding.name,
        sender_username: user.email ?? "Administrator",
        holding_name: holding.name,
        nevu_code: holding.code,
        message: value
      })
      .select("id,holding_id,sender_legal_name,sender_username,holding_name,nevu_code,message,created_at")
      .single();

    if (insertError) setError(insertError.message);
    else {
      if (row) setMessages(prev => prev.some(m => m.id === row.id) ? prev : [...prev, row as Message]);
      setText("");
    }
    setSending(false);
  }

  function handleKeyDown(e: KeyboardEvent<HTMLTextAreaElement>) {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      void sendMessage();
    }
  }

  return (
    <main className="min-h-screen">
      <TopBar title={holding?.name ?? "NEVU"} subtitle="Private Holding Board Room" />

      <div className="mx-auto grid h-[calc(100vh-4rem)] max-w-[1500px] grid-cols-1 gap-4 p-3 md:p-5 lg:grid-cols-[250px_1fr_280px]">
        <aside className="glass hidden rounded-3xl p-3 lg:flex lg:flex-col">
          <Link href="/holding" className="rounded-2xl px-3 py-3 text-sm text-white/55 hover:bg-white/5 hover:text-white">← Holding Home</Link>
          <div className="mt-5 px-3 text-[10px] uppercase tracking-[.22em] text-white/30">Board Room</div>
          <div className="mt-2 rounded-2xl bg-white/8 px-3 py-3 text-sm text-white">Administrator + Agents</div>
          <div className="mt-1 rounded-2xl px-3 py-3 text-sm text-white/45">Governance</div>
          <div className="mt-auto rounded-2xl border border-white/8 bg-white/[.03] p-4">
            <div className="text-xs text-white/35">Connection</div>
            <div className="mt-2 flex items-center gap-2 text-sm">
              <span className={`h-2 w-2 rounded-full ${connected ? "bg-emerald-300" : "bg-white/20"}`} />
              {connected ? "Realtime connected" : "Connecting…"}
            </div>
          </div>
        </aside>

        <section className="glass flex min-h-0 flex-col overflow-hidden rounded-[2rem]">
          <div className="flex items-center justify-between border-b border-white/8 px-4 py-4 md:px-6">
            <div>
              <div className="text-base font-medium">{holding?.name ?? "Holding Board Room"}</div>
              <div className="mt-1 text-xs text-white/35">Private conversation · {holding?.code ?? "NEVU"}</div>
            </div>
            <div className="flex items-center gap-2 rounded-full border border-white/8 bg-white/5 px-3 py-1.5 text-[11px] text-white/45">
              <span className={`h-1.5 w-1.5 rounded-full ${connected ? "bg-emerald-300" : "bg-white/20"}`} />
              {connected ? "Live" : "Offline"}
            </div>
          </div>

          <div className="min-h-0 flex-1 overflow-y-auto px-3 py-5 md:px-6">
            {loading ? (
              <div className="grid h-full place-items-center text-sm text-white/35">Loading Board Room…</div>
            ) : error && !messages.length ? (
              <div className="grid h-full place-items-center p-6 text-center">
                <div><div className="text-sm text-white/70">Board Room unavailable</div><div className="mt-2 max-w-md text-xs leading-5 text-white/35">{error}</div></div>
              </div>
            ) : messages.length === 0 ? (
              <div className="grid h-full place-items-center p-6 text-center">
                <div>
                  <div className="mx-auto grid h-16 w-16 place-items-center rounded-3xl border border-white/10 bg-white/5 text-2xl">✦</div>
                  <div className="mt-5 text-lg font-medium">Your Board Room is ready</div>
                  <div className="mt-2 max-w-sm text-sm leading-6 text-white/35">Start the private conversation with your holding. Agents and governance workflow will be added around this room.</div>
                </div>
              </div>
            ) : (
              <div className="mx-auto max-w-3xl space-y-5">
                {messages.map((m, i) => {
                  const mine = m.sender_username === (user?.email ?? "");
                  const previous = messages[i - 1];
                  const showDay = !previous || new Date(previous.created_at).toDateString() !== new Date(m.created_at).toDateString();
                  return (
                    <div key={m.id}>
                      {showDay && <div className="my-5 text-center text-[10px] uppercase tracking-[.18em] text-white/25">{formatDay(m.created_at)}</div>}
                      <div className={`flex ${mine ? "justify-end" : "justify-start"}`}>
                        <div className={`max-w-[88%] rounded-3xl px-4 py-3 ${mine ? "bg-white text-black" : "border border-white/8 bg-white/[.055] text-white"}`}>
                          <div className={`mb-1 text-[10px] font-medium ${mine ? "text-black/45" : "text-white/35"}`}>{m.sender_username}</div>
                          <div className="whitespace-pre-wrap break-words text-sm leading-6">{m.message}</div>
                          <div className={`mt-1.5 text-right text-[10px] ${mine ? "text-black/35" : "text-white/25"}`}>{formatTime(m.created_at)}</div>
                        </div>
                      </div>
                    </div>
                  );
                })}
                <div ref={bottomRef} />
              </div>
            )}
          </div>

          <form onSubmit={sendMessage} className="border-t border-white/8 p-3 md:p-4">
            {error && messages.length > 0 && <div className="mb-2 rounded-xl bg-red-400/8 px-3 py-2 text-xs text-red-200/70">{error}</div>}
            <div className="mx-auto flex max-w-3xl items-end gap-2 rounded-3xl border border-white/10 bg-black/20 p-2">
              <button type="button" title="Attachments will be added next" className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl text-lg text-white/35 hover:bg-white/6 hover:text-white">＋</button>
              <textarea
                value={text}
                onChange={e => setText(e.target.value)}
                onKeyDown={handleKeyDown}
                rows={1}
                placeholder="Message your Board Room…"
                className="max-h-32 min-h-11 flex-1 bg-transparent px-2 py-3 text-sm outline-none placeholder:text-white/25"
              />
              <button disabled={!text.trim() || sending} type="submit" className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl bg-white text-black disabled:opacity-30" title="Send">
                {sending ? "…" : "↑"}
              </button>
            </div>
            <div className="mx-auto mt-2 max-w-3xl px-3 text-[10px] text-white/20">Enter to send · Shift+Enter for a new line</div>
          </form>
        </section>

        <aside className="glass hidden rounded-3xl p-5 xl:block">
          <div className="text-xs uppercase tracking-[.2em] text-white/30">Room Context</div>
          <div className="mt-5 rounded-2xl bg-white/5 p-4">
            <div className="text-sm font-medium">{holding?.name ?? "Holding"}</div>
            <div className="mt-1 text-xs text-white/35">{holding?.code ?? "NEVU"}</div>
          </div>
          <div className="mt-4 space-y-2 text-sm text-white/45">
            <div className="rounded-2xl border border-white/7 p-3">Private holding channel</div>
            <div className="rounded-2xl border border-white/7 p-3">Realtime messages</div>
            <div className="rounded-2xl border border-white/7 p-3">Agents: next layer</div>
            <div className="rounded-2xl border border-white/7 p-3">Approval workflow: next layer</div>
          </div>
        </aside>
      </div>
    </main>
  );
}
