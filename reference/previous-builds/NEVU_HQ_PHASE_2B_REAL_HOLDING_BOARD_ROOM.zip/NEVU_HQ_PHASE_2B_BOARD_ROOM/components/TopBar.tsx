import Link from "next/link";

export function TopBar({ title = "NEVU", subtitle = "Holding Workspace" }: { title?: string; subtitle?: string }) {
  return (
    <header className="sticky top-0 z-30 border-b border-white/10 bg-black/25 backdrop-blur-2xl">
      <div className="mx-auto flex h-16 max-w-[1500px] items-center justify-between px-4 md:px-7">
        <Link href="/holding" className="flex items-center gap-3">
          <div className="grid h-9 w-9 place-items-center rounded-xl border border-white/10 bg-white/5 text-sm font-semibold">N</div>
          <div>
            <div className="text-sm font-semibold tracking-[.18em]">{title}</div>
            <div className="text-[10px] uppercase tracking-[.22em] text-white/40">{subtitle}</div>
          </div>
        </Link>
        <div className="flex items-center gap-2">
          <Link href="/holding" className="rounded-xl px-3 py-2 text-sm text-white/60 hover:bg-white/6 hover:text-white">Holding Home</Link>
          <Link href="/hq" className="rounded-xl border border-white/10 bg-white/6 px-3 py-2 text-sm text-white hover:bg-white/10">NEVU HQ</Link>
        </div>
      </div>
    </header>
  );
}
