# NEVU HQ — Phase 2B: Holding Board Room

This package adds a real, Supabase-backed private Holding Board Room to the Phase 2A application shell.

## What is included

- Realtime `public.nevu_messages` subscription
- Load existing messages for the authenticated administrator's holding
- Send text messages
- Enter to send / Shift+Enter for a new line
- Private holding isolation using the existing RLS policies
- Responsive WhatsApp-style conversation surface
- Automatic scroll to the newest message
- Connection state indicator
- Empty-state presentation
- Holding identity loaded from the existing `public.holdings` row

## Environment

Copy `.env.local.example` to `.env.local` and use the same Supabase project URL and publishable key as Phase 2A.

## Database

This expects the `public.nevu_messages` table and realtime publication you already created.

The table is expected to contain:
- id
- holding_id
- sender_legal_name
- sender_username
- holding_name
- nevu_code
- message
- created_at

## Run

npm install
npm run dev

Then open:
http://localhost:3000/holding/board-room

## Security

The client never receives a service-role key. Reads and inserts are governed by the existing authenticated RLS policies. The Board Room only queries messages for the current user's holding.
